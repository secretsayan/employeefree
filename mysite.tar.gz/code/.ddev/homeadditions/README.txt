#ddev-generated
Files in .ddev/homeadditions will be copied into the web container's home directory.

An example bash_aliases.example is provided here. To make this file active you can either

cp bash_aliases.example .bash_aliases
or ln -s bash_aliases.example .bash_aliases
